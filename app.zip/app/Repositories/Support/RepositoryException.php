<?php

namespace App\Repositories\Support;

class RepositoryException extends \UnexpectedValueException {};